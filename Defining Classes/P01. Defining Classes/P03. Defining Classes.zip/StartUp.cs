﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main()
        {

            int membersCount = int.Parse(Console.ReadLine());

            Family family = new Family();

            for (int i = 0; i < membersCount; i++)
            {
                string[] infoLine = Console.ReadLine().Split();
                string personName = infoLine[0];
                int personAge = int.Parse(infoLine[1]);

                Person member = new Person(personName, personAge);

                family.AddMember(member);
            }

            Person oldestMember = family.GetOldestMember();
            Console.WriteLine($"{oldestMember.Name} {oldestMember.Age}");
        }
    }
}
